import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";

export default function TelegramOnboardingPage() {
  return (
    <div className="cyber-grid flex min-h-screen items-center justify-center bg-page-bg px-4">
      <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-xl">
      <Card className="w-full max-w-xl text-center neo-glow">
        <p className="text-xs uppercase tracking-wider text-accent-gold">Step Required</p>
        <h1 className="mt-2 text-2xl font-semibold">Account created successfully</h1>
        <p className="mt-3 text-text-secondary">
          Please join the official Telegram group to continue.
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
          <a href="https://t.me/" target="_blank" rel="noreferrer">
            <Button>Join Telegram Group</Button>
          </a>
          <Link to="/login">
            <Button variant="secondary">I Have Joined</Button>
          </Link>
        </div>
      </Card>
      </motion.div>
    </div>
  );
}
