import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";

export default function PrivacyPage() {
  const points = [
    {
      title: "Data We Collect",
      text: "We collect account, referral, and onboarding details required to provide platform access and member features.",
    },
    {
      title: "How We Use Data",
      text: "Information is used for account operations, network display, onboarding communication, and notifications.",
    },
    {
      title: "Security & Retention",
      text: "For compliance and security, activity and account change history may be retained for audit purposes.",
    },
    {
      title: "Legal Placeholder",
      text: "This UI page is a design placeholder and must be replaced with approved legal copy before production release.",
    },
  ];

  return (
    <div className="relative min-h-screen overflow-hidden bg-[linear-gradient(180deg,#0f3b2f_0%,#144a39_34%,#1b5a45_68%,#215f4a_100%)] px-4 py-10 md:px-8">
      <div className="pointer-events-none absolute inset-0 opacity-60 [background:radial-gradient(circle_at_10%_12%,rgba(201,162,39,.24),transparent_36%),radial-gradient(circle_at_90%_18%,rgba(255,255,255,.10),transparent_42%)]" />
      <div className="mx-auto w-full max-w-[980px] space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="flex flex-wrap items-center justify-between gap-3"
        >
          <h1 className="text-3xl font-semibold">Privacy Policy</h1>
          <Link to="/">
            <Button variant="secondary">Back to Landing</Button>
          </Link>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.05 }}
        >
          <Card className="border border-accent-gold/35 !bg-gradient-to-br from-white/95 via-white/90 to-brand-green-muted/65 shadow-2xl">
            <div className="mb-5 rounded-xl border border-accent-gold/25 bg-accent-gold/10 px-4 py-3 text-sm text-brand-green">
              Effective date: April 2026
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              {points.map((item, idx) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.08 + idx * 0.08 }}
                  whileHover={{ y: -3 }}
                  className="rounded-xl border border-border-subtle bg-white/75 p-4 shadow-sm"
                >
                  <h3 className="text-sm font-semibold text-brand-green">{item.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-text-secondary">{item.text}</p>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
