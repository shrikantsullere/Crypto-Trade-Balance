import { motion } from "framer-motion";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import Input from "../components/ui/Input";

export default function RegisterPage() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const refCode = params.get("ref") || "TB-CHRISTINA-001";

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[linear-gradient(180deg,#0f3b2f_0%,#144a39_32%,#1a5a45_62%,#205f49_100%)] px-4 py-8">
      <div className="pointer-events-none absolute inset-0 opacity-60 [background:radial-gradient(circle_at_12%_8%,rgba(201,162,39,.22),transparent_34%),radial-gradient(circle_at_86%_16%,rgba(255,255,255,.10),transparent_40%),radial-gradient(circle_at_50%_64%,rgba(201,162,39,.14),transparent_48%)]" />
      <div className="pointer-events-none absolute -left-24 top-16 h-72 w-72 rounded-full bg-accent-gold/18 blur-3xl" />
      <div className="pointer-events-none absolute -right-20 bottom-20 h-72 w-72 rounded-full bg-white/10 blur-3xl" />

      <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="relative z-10 w-full max-w-md">
        <Card className="w-full max-w-md neo-glow">
          <Button
            type="button"
            variant="secondary"
            className="mb-4"
            onClick={() => navigate("/")}
          >
            Back
          </Button>
          <div className="mb-6">
            <p className="text-xs uppercase tracking-wider text-accent-gold">Pre-launch Join</p>
            <h1 className="mt-2 text-2xl font-semibold">Create your account</h1>
          </div>
          <form className="space-y-4">
            <Input label="Full Name" placeholder="Your full name" />
            <Input label="Email or Phone" placeholder="you@example.com" />
            <Input label="Password" type="password" placeholder="********" />
            <Input label="Confirm Password" type="password" placeholder="********" />
            <Input label="Referral Code" defaultValue={refCode} />
            <Link to="/telegram-onboarding" className="block">
              <Button className="w-full">Create Account</Button>
            </Link>
            <p className="text-center text-sm text-text-secondary">
              Already have an account?{" "}
              <Link to="/login" className="font-semibold text-brand-green">
                Login
              </Link>
            </p>
          </form>
        </Card>
      </motion.div>
    </div>
  );
}
