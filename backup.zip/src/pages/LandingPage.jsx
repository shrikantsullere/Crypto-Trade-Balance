import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import brandLogo from "../assets/trade-logo-final.png";
import lionLogo from "../assets/lion-logo-transparent.png";
import heroRightVisual from "../assets/hero-right-custom.svg";
import peopleTable from "../assets/people_table.png";
import ParticleBackground from "../components/ui/ParticleBackground";

const reveal = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, amount: 0.2 },
  transition: { duration: 0.45, ease: "easeOut" },
};
const fromLeft = {
  initial: { opacity: 0, x: -36 },
  whileInView: { opacity: 1, x: 0 },
  viewport: { once: true, amount: 0.2 },
  transition: { duration: 0.5, ease: "easeOut" },
};
const fromRight = {
  initial: { opacity: 0, x: 36 },
  whileInView: { opacity: 1, x: 0 },
  viewport: { once: true, amount: 0.2 },
  transition: { duration: 0.5, ease: "easeOut" },
};
const fromTop = {
  initial: { opacity: 0, y: -30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, amount: 0.2 },
  transition: { duration: 0.48, ease: "easeOut" },
};
const fromBottom = {
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, amount: 0.2 },
  transition: { duration: 0.48, ease: "easeOut" },
};
const floatingParticles = [
  { left: "8%", top: "20%", delay: 0, duration: 9 },
  { left: "18%", top: "72%", delay: 0.8, duration: 10 },
  { left: "34%", top: "30%", delay: 1.4, duration: 8.5 },
  { left: "48%", top: "62%", delay: 0.4, duration: 9.8 },
  { left: "62%", top: "24%", delay: 1.1, duration: 10.5 },
  { left: "74%", top: "68%", delay: 0.2, duration: 9.2 },
  { left: "86%", top: "36%", delay: 1.7, duration: 8.8 },
];
const onboardingFlow = [
  {
    step: "01",
    title: "Register & Secure Identity",
    text: "Create your account with premium onboarding flow and referral-linked entry.",
  },
  {
    step: "02",
    title: "Join Official Community",
    text: "Complete Telegram onboarding to receive official launch updates and guidance.",
  },
  {
    step: "03",
    title: "Activate Backoffice",
    text: "Track network, share referral links, download documents, and chat with support.",
  },
];
const moduleHighlights = [
  { title: "Dashboard Intelligence", text: "KPI snapshot and quick actions." },
  { title: "Referral & Network", text: "Track team growth and sharing flow." },
  { title: "Downloads & Support", text: "Access PDFs and support instantly." },
];
const card3dHover = {
  y: -8,
  scale: 1.015,
  rotateX: 5,
  rotateY: -5,
  transition: { duration: 0.28, ease: "easeOut" },
};
const numberPad = (value) => String(value).padStart(2, "0");

function getDeadline() {
  const now = new Date();
  const target = new Date(now.getFullYear(), 6, 4, 23, 59, 59);
  if (now > target) {
    return new Date(now.getFullYear() + 1, 6, 4, 23, 59, 59);
  }
  return target;
}

function getTimeLeft(targetDate) {
  const delta = targetDate.getTime() - Date.now();
  if (delta <= 0) {
    return { days: "00", hours: "00", minutes: "00", seconds: "00" };
  }
  const days = Math.floor(delta / (1000 * 60 * 60 * 24));
  const hours = Math.floor((delta / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((delta / (1000 * 60)) % 60);
  const seconds = Math.floor((delta / 1000) % 60);
  return {
    days: numberPad(days),
    hours: numberPad(hours),
    minutes: numberPad(minutes),
    seconds: numberPad(seconds),
  };
}

function FlipUnit({ value, label }) {
  return (
    <motion.div
      className="rounded-xl border border-accent-gold/20 bg-gradient-to-br from-white/[0.16] to-black/25 p-3 text-center"
      whileHover={{ y: -3, scale: 1.02, boxShadow: "0 0 28px rgba(201,162,39,0.26)" }}
      transition={{ duration: 0.34, ease: "easeInOut" }}
    >
      <div className="relative overflow-hidden rounded-lg border border-white/20 bg-black/25 px-4 py-2.5">
        <motion.div
          className="pointer-events-none absolute inset-0"
          animate={{
            boxShadow: [
              "inset 0 0 0 rgba(201,162,39,0.0)",
              "inset 0 0 20px rgba(201,162,39,0.18)",
              "inset 0 0 0 rgba(201,162,39,0.0)",
            ],
          }}
          transition={{ duration: 2.8, repeat: Infinity, ease: "easeInOut" }}
        />
        <AnimatePresence mode="wait">
          <motion.p
            key={value}
            initial={{ rotateX: -70, opacity: 0, y: -8 }}
            animate={{ rotateX: 0, opacity: 1, y: 0 }}
            exit={{ rotateX: 70, opacity: 0, y: 8 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="text-lg font-semibold text-white md:text-2xl"
          >
            {value}
          </motion.p>
        </AnimatePresence>
      </div>
      <p className="pt-2 text-xs text-white/70">{label}</p>
    </motion.div>
  );
}

export default function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [timeLeft, setTimeLeft] = useState(() => getTimeLeft(getDeadline()));
  const deadline = useMemo(() => getDeadline(), []);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setTimeLeft(getTimeLeft(deadline));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [deadline]);

  const scrollToSection = (sectionId) => {
    const section = document.getElementById(sectionId);
    if (!section) return;
    const y = section.getBoundingClientRect().top + window.scrollY - 84;
    window.scrollTo({ top: y, behavior: "smooth" });
    setMobileMenuOpen(false);
  };

  return (
    <div className="cosmic-theme relative min-h-screen overflow-x-hidden">
      <ParticleBackground />
      
      <header className="fixed inset-x-0 top-0 z-40 border-b border-accent-gold/20 bg-black/40 text-white backdrop-blur-xl">
        <div className="mx-auto flex w-full max-w-[1200px] items-center justify-between px-4 py-3 md:px-8">
          <img src={brandLogo} alt="Trade Balance logo" className="h-11 w-auto object-contain drop-shadow-[0_10px_24px_rgba(0,0,0,0.5)] md:h-12" />

          <nav className="hidden items-center gap-6 text-sm font-medium text-white/90 lg:flex">
            {[
              { id: "#hero", label: "Home" },
              { id: "#telegram", label: "Community" },
              { id: "#video", label: "Video" },
              { id: "#scarcity", label: "Countdown" },
              { id: "#features", label: "Features" },
            ].map((item) => (
              <a key={item.id} href={item.id} className="group relative transition text-hover-gold">
                <span className="transition-all duration-300 group-hover:translate-y-[-1px] group-hover:drop-shadow-[0_0_12px_rgba(201,162,39,0.9)]">{item.label}</span>
                <span className="absolute -bottom-1 left-0 h-px w-0 bg-accent-gold transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          <div className="hidden items-center gap-3 sm:flex">
            <Link to="/login">
              <Button variant="secondary" className="border-accent-gold/40 bg-white/5 text-white hover:bg-white/15">Login</Button>
            </Link>
            <Link to="/register">
              <Button className="shine-wrap bg-gradient-to-r from-[#b9912f] via-[#e1c46b] to-[#b8912f] text-black hover:brightness-105">Register</Button>
            </Link>
          </div>

          <button
            type="button"
            className="rounded-lg border border-white/25 bg-white/10 px-3 py-2 text-sm text-white lg:hidden"
            onClick={() => setMobileMenuOpen((v) => !v)}
          >
            {mobileMenuOpen ? "Close" : "Menu"}
          </button>
        </div>

        {mobileMenuOpen ? (
          <div className="border-t border-white/15 bg-brand-green/95 px-4 py-4 lg:hidden">
            <div className="flex flex-col gap-2 text-sm">
              <button type="button" className="rounded-lg px-2 py-2 text-left hover:bg-white/10" onClick={() => scrollToSection("hero")}>Home</button>
              <button type="button" className="rounded-lg px-2 py-2 text-left hover:bg-white/10" onClick={() => scrollToSection("telegram")}>Community</button>
              <button type="button" className="rounded-lg px-2 py-2 text-left hover:bg-white/10" onClick={() => scrollToSection("video")}>Video</button>
              <button type="button" className="rounded-lg px-2 py-2 text-left hover:bg-white/10" onClick={() => scrollToSection("scarcity")}>Countdown</button>
              <button type="button" className="rounded-lg px-2 py-2 text-left hover:bg-white/10" onClick={() => scrollToSection("features")}>Features</button>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:hidden">
              <Link to="/login" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="secondary" className="w-full border-white/35 bg-white/10 text-white hover:bg-white/20">Login</Button>
              </Link>
              <Link to="/register" onClick={() => setMobileMenuOpen(false)}>
                <Button className="w-full bg-gradient-to-r from-accent-gold to-[#d8b74f] text-black hover:brightness-105">Register</Button>
              </Link>
            </div>
          </div>
        ) : null}
      </header>

      <main className="relative z-10 pt-[72px]">
        <motion.section id="hero" className="relative flex min-h-[calc(100vh-72px)] items-center overflow-hidden border-b border-white/5 bg-transparent text-white" {...reveal}>
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(201,162,39,0.05),transparent_70%)]" />
          <div className="mx-auto grid w-full max-w-[1200px] gap-10 px-4 py-10 md:grid-cols-2 md:px-8">
            <motion.div className="space-y-7 self-center" {...fromLeft}>
              <div className="flex flex-col items-start gap-4">
                <div className="inline-flex items-center gap-3 rounded-2xl border border-accent-gold/35 bg-black/30 px-4 py-2.5 backdrop-blur">
                  <img src={lionLogo} alt="Lion mark" className="h-10 w-10 object-contain float-slow" />
                  <span className="text-sm font-medium uppercase tracking-[0.16em] text-accent-gold">Trade Balance</span>
                </div>
                <motion.p className="inline-flex rounded-full border border-accent-gold/55 bg-accent-gold/12 px-3 py-1 text-sm font-semibold uppercase tracking-wide text-accent-gold" animate={{ boxShadow: ["0 0 0 rgba(201,162,39,0)", "0 0 26px rgba(201,162,39,0.35)", "0 0 0 rgba(201,162,39,0)"] }} transition={{ duration: 2.8, repeat: Infinity, ease: "easeInOut" }}>
                  Pre-launch access
                </motion.p>
              </div>
              <motion.h1 initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }} whileHover={{ scale: 1.01, textShadow: "0 0 22px rgba(201,162,39,0.7)" }} className="text-4xl font-semibold leading-tight md:text-6xl md:leading-tight text-hover-gold">
                Start Now and Change Your Life
              </motion.h1>
              <p className="max-w-xl text-base text-white/80 text-hover-gold">
                Become financially independent with a luxury-grade onboarding journey and conversion-focused premium member experience.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link to="/register">
                  <Button className="shine-wrap bg-gradient-to-r from-[#b9912f] via-[#e1c46b] to-[#b8912f] text-black shadow-[0_14px_26px_-14px_rgba(201,162,39,.8)] hover:brightness-105">Register Now</Button>
                </Link>
                <a href="https://t.me/" target="_blank" rel="noreferrer">
                  <Button variant="secondary" className="border-accent-gold/35 bg-white/5 text-white hover:bg-white/15">
                    Join Telegram
                  </Button>
                </a>
              </div>
            </motion.div>
            <motion.div {...fromRight} whileHover={{ y: -6, rotateY: 3 }} transition={{ duration: 0.3 }} className="md:col-span-1">
              <Card title="Executive Board" className="gold-ring border border-accent-gold/30 !bg-gradient-to-br from-[#171b18]/85 to-[#0d100e]/80 text-white backdrop-blur">
                <motion.div initial={{ opacity: 0, scale: 0.96, y: 12 }} whileInView={{ opacity: 1, scale: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }} animate={{ y: [0, -4, 0] }} className="relative overflow-hidden rounded-2xl border border-white/20 bg-black/15 shadow-[0_0_50px_rgba(201,162,39,0.2)]">
                  <motion.div className="pointer-events-none absolute -left-1/3 top-0 h-full w-1/2 bg-gradient-to-r from-transparent via-white/20 to-transparent" animate={{ x: ["-20%", "220%"] }} transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut", repeatDelay: 1.4 }} />
                  <img src={peopleTable} alt="Trade Balance premium board meeting" className="h-64 w-full object-cover md:h-72" onError={(e) => { e.target.src = heroRightVisual; }} />
                </motion.div>
                <div className="mt-4 space-y-2">
                  <p className="text-sm font-semibold text-accent-gold">Global Intelligence Table</p>
                  <p className="text-sm text-white/70">Experience the next generation of financial decision making in a cinematic cosmic environment.</p>
                </div>
              </Card>
            </motion.div>
          </div>
        </motion.section>

        <motion.section className="relative flex min-h-[56vh] items-center border-b border-white/10 bg-transparent py-20 md:py-24" {...reveal}>
          <div className="pointer-events-none absolute left-10 top-10 h-44 w-44 rounded-full bg-accent-gold/15 blur-3xl" />
          <div className="pointer-events-none absolute bottom-8 right-14 h-52 w-52 rounded-full bg-white/10 blur-3xl" />
          <motion.div className="mx-auto grid w-full max-w-[1200px] gap-6 px-4 md:grid-cols-4 md:px-8" {...fromTop}>
            {[
              { label: "Pre-launch Members", value: "12,500+" },
              { label: "Referral Teams Built", value: "2,300+" },
              { label: "Countries Connected", value: "24+" },
              { label: "Community Satisfaction", value: "98%" },
            ].map((item, idx) => (
              <motion.div key={item.label} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: idx * 0.06 }} whileHover={card3dHover} style={{ transformStyle: "preserve-3d" }}>
                <Card className="border border-accent-gold/35 !bg-gradient-to-br from-[#171b18]/85 to-black/20 text-white shadow-lg shadow-black/25">
                  <p className="text-xs uppercase tracking-wider text-white/75">{item.label}</p>
                  <motion.p className="mt-2 text-3xl font-semibold text-white" whileHover={{ scale: 1.03, color: "#D9BA57" }} transition={{ duration: 0.2 }}>
                    {item.value}
                  </motion.p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </motion.section>

        <motion.section id="telegram" className="relative flex min-h-[62vh] items-center border-b border-white/10 bg-transparent py-20 md:py-24" {...reveal}>
          <motion.div className="pointer-events-none absolute -left-10 top-24 h-48 w-48 rounded-full bg-accent-gold/12 blur-3xl" animate={{ y: [0, -10, 0] }} transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }} />
          <div className="mx-auto grid w-full max-w-[1200px] gap-8 px-4 md:grid-cols-2 md:px-8">
            <motion.div className="space-y-5 self-center" {...fromLeft}>
              <p className="text-xs font-semibold uppercase tracking-wider text-accent-gold">Official Telegram Community</p>
              <h2 className="text-3xl font-semibold leading-tight md:text-4xl">Connect instantly with leaders and official updates.</h2>
              <p className="text-white/85">Join the official community to get onboarding guidance, launch announcements, and practical growth tips.</p>
              <a href="https://t.me/" target="_blank" rel="noreferrer">
                <Button className="shine-wrap bg-gradient-to-r from-accent-gold to-[#d8b74f] text-black hover:brightness-105">Join Official Telegram</Button>
              </a>
            </motion.div>
            <motion.div {...fromRight} whileHover={card3dHover} style={{ transformStyle: "preserve-3d" }}>
              <Card className="border border-accent-gold/30 !bg-gradient-to-br from-[#151916]/85 to-black/25 text-white shadow-xl shadow-black/25">
                <div className="space-y-3">
                  {[
                    "Daily updates from the core team",
                    "Priority onboarding support for new members",
                    "Exclusive pre-launch strategy sessions",
                    "Instant referral campaign announcements",
                  ].map((item) => (
                    <motion.div key={item} whileHover={{ x: 6, scale: 1.01, boxShadow: "0 0 16px rgba(201,162,39,0.3)" }} className="rounded-xl border border-accent-gold/25 bg-gradient-to-r from-[#171b18]/85 to-black/20 px-4 py-3 text-sm shadow-[inset_0_0_0_1px_rgba(255,255,255,0.06)]">
                      {item}
                    </motion.div>
                  ))}
                </div>
              </Card>
            </motion.div>
          </div>
        </motion.section>

        <motion.section id="video" className="relative flex min-h-[62vh] items-center border-b border-white/10 bg-transparent py-20 md:py-24" {...reveal}>
          <div className="pointer-events-none absolute right-10 top-16 h-56 w-56 rounded-full bg-accent-gold/10 blur-3xl" />
          <div className="mx-auto grid w-full max-w-[1200px] gap-8 px-4 md:grid-cols-2 md:px-8">
            <motion.div {...fromLeft} whileHover={{ ...card3dHover, rotateY: 4 }} style={{ transformStyle: "preserve-3d" }}>
              <Card className="border border-accent-gold/35 !bg-gradient-to-br from-[#171f1a]/92 via-[#101814] to-[#090c0a] text-white shadow-2xl shadow-black/35 overflow-hidden p-0">
                <div className="relative aspect-video overflow-hidden group">
                  <img src={peopleTable} alt="Hollywood Style Trailer Preview" className="h-full w-full object-contain transition-transform duration-700 group-hover:scale-105" onError={(e) => { e.target.src = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop"; }} />
                  <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="h-16 w-16 rounded-full bg-accent-gold/90 flex items-center justify-center shadow-[0_0_40px_rgba(201,162,39,0.7)] hover:scale-110 transition-transform">
                      <div className="border-l-[15px] border-l-black border-y-[10px] border-y-transparent ml-1" />
                    </div>
                    <p className="mt-4 text-sm font-bold tracking-widest uppercase text-accent-gold">Play Trailer</p>
                  </div>
                  <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,transparent_0%,rgba(0,0,0,0.4)_100%)]" />
                </div>
              </Card>
            </motion.div>
            <motion.div className="space-y-4 self-center" {...fromRight}>
              <p className="text-xs font-semibold uppercase tracking-wider text-accent-gold">Launch Story</p>
              <h2 className="text-3xl font-semibold leading-tight md:text-4xl">Elegant system design with clear earning visibility.</h2>
              <p className="text-white/85">Watch the walkthrough before registration to understand referral flow, network growth, and dashboard experience.</p>
            </motion.div>
          </div>
        </motion.section>

        <motion.section id="scarcity" className="relative flex min-h-[62vh] items-center border-b border-white/10 bg-transparent py-20 md:py-24" {...reveal}>
          <motion.div
            className="pointer-events-none absolute left-20 top-14 h-44 w-44 rounded-full bg-accent-gold/20 blur-3xl"
            animate={{ opacity: [0.2, 0.45, 0.2], scale: [1, 1.1, 1] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div
            className="pointer-events-none absolute bottom-10 right-14 h-52 w-52 rounded-full bg-[#2f5a49]/35 blur-3xl"
            animate={{ opacity: [0.25, 0.5, 0.25], scale: [1, 1.08, 1] }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div className="mx-auto w-full max-w-[1200px] px-4 md:px-8" {...fromBottom}>
            <motion.div whileHover={{ y: -6, scale: 1.01 }} transition={{ duration: 0.25 }}>
              <Card className="relative overflow-hidden border border-accent-gold/45 !bg-gradient-to-br from-[#151917]/95 via-[#0f1210]/92 to-[#080a09]/90 text-white shadow-[0_30px_56px_-26px_rgba(0,0,0,0.76)]">
                <motion.div
                  className="pointer-events-none absolute inset-0"
                  animate={{
                    boxShadow: [
                      "inset 0 0 0 rgba(201,162,39,0.0)",
                      "inset 0 0 60px rgba(201,162,39,0.15)",
                      "inset 0 0 0 rgba(201,162,39,0.0)",
                    ],
                  }}
                  transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut" }}
                />
                <div className="mb-3">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-accent-gold">Limited Time Left</p>
                </div>
                <div className="grid grid-cols-2 gap-3 text-center sm:grid-cols-4">
                  <FlipUnit value={timeLeft.days} label="Days" />
                  <FlipUnit value={timeLeft.hours} label="Hours" />
                  <FlipUnit value={timeLeft.minutes} label="Minutes" />
                  <FlipUnit value={timeLeft.seconds} label="Seconds" />
                </div>
                <p className="mt-4 text-sm text-white/80">Limited onboarding slots are available before launch window closes.</p>
              </Card>
            </motion.div>
            <motion.div {...fromTop} whileHover={{ y: -6, scale: 1.01 }} transition={{ duration: 0.25 }}>
              <Card className="mt-8 border border-accent-gold/45 !bg-gradient-to-r from-[#151917]/95 via-[#0f1210]/92 to-[#090a09]/90 text-white shadow-[0_30px_56px_-26px_rgba(0,0,0,0.76)]">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-accent-gold">Final Registration Push</p>
                    <h3 className="mt-1 text-xl font-semibold">Secure your pre-launch position now.</h3>
                  </div>
                  <Link to="/register">
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.98 }}
                      animate={{ y: [0, -1.5, 0] }}
                      transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
                    >
                      <Button className="shine-wrap bg-gradient-to-r from-[#b9912f] via-[#e1c46b] to-[#b8912f] text-black shadow-[0_0_34px_-8px_rgba(201,162,39,0.95)] hover:brightness-105">Join Before 4th July</Button>
                    </motion.div>
                  </Link>
                </div>
              </Card>
            </motion.div>
          </motion.div>
        </motion.section>

        <motion.section id="features" className="relative flex min-h-[62vh] items-center bg-transparent py-20 md:py-24" {...reveal}>
          <div className="pointer-events-none absolute bottom-10 right-16 h-52 w-52 rounded-full bg-accent-gold/10 blur-3xl" />
          <motion.div className="mx-auto grid w-full max-w-[1200px] gap-6 px-4 md:grid-cols-3 md:px-8" {...fromBottom}>
            {[
              { title: "Clean Growth System", text: "Structured referral flow, clear hierarchy, and premium dashboard design for daily action." },
              { title: "Premium Member Experience", text: "Luxury visual identity with professional spacing, readability, and elegant interaction effects." },
              { title: "Launch-Ready Journey", text: "From landing to onboarding to dashboard, every step is clear, smooth, and conversion-focused." },
            ].map((item, idx) => (
              <motion.div key={item.title} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: idx * 0.08 }} whileHover={{ ...card3dHover, rotateY: idx % 2 === 0 ? -4 : 4 }} style={{ transformStyle: "preserve-3d" }}>
                <Card className="border border-accent-gold/35 !bg-gradient-to-br from-[#171b18]/85 to-black/20 text-white shadow-lg shadow-black/25">
                  <div className="mb-3 h-9 w-9 rounded-lg border border-accent-gold/40 bg-accent-gold/20 shadow-[0_8px_18px_-10px_rgba(201,162,39,0.9)]" />
                  <p className="text-xs font-semibold uppercase tracking-wider text-accent-gold">Why Trade Balance</p>
                  <h4 className="mt-2 text-xl font-semibold">{item.title}</h4>
                  <p className="mt-3 text-sm leading-6 text-white/80">{item.text}</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </motion.section>

        <motion.section className="relative flex min-h-[64vh] items-center border-t border-white/10 bg-transparent py-20 md:py-24" {...reveal}>
          <div className="pointer-events-none absolute left-16 top-12 h-56 w-56 rounded-full bg-accent-gold/10 blur-3xl" />
          <div className="mx-auto w-full max-w-[1200px] px-4 md:px-8">
            <motion.div className="space-y-5" {...fromTop}>
              <p className="text-xs font-semibold uppercase tracking-wider text-accent-gold">How It Works</p>
              <h2 className="text-3xl font-semibold leading-tight md:text-4xl">Simple onboarding. Strong execution. Premium support.</h2>
              <p className="text-white/80">Landing structure same rakh ke sirf cinematic premium animations enhance ki gayi hain for better engagement.</p>
              <div className="grid gap-4 md:grid-cols-3">
                {onboardingFlow.map((item, idx) => (
                  <motion.div key={item.step} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: idx * 0.08 }} whileHover={card3dHover} style={{ transformStyle: "preserve-3d" }}>
                    <Card className="h-full border border-accent-gold/25 !bg-gradient-to-r from-[#171b18]/85 to-black/20 text-white">
                      <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl border border-accent-gold/45 bg-accent-gold/20 text-sm font-semibold text-accent-gold">{item.step}</div>
                      <p className="text-lg font-semibold">{item.title}</p>
                      <p className="mt-2 text-sm leading-6 text-white/75">{item.text}</p>
                      <p className="mt-4 text-xs uppercase tracking-wider text-accent-gold/90">Step {idx + 1}</p>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </motion.section>

        <motion.section className="relative flex min-h-[52vh] items-center border-t border-white/10 bg-transparent py-16 md:py-20" {...reveal}>
          <div className="pointer-events-none absolute bottom-10 right-10 h-56 w-56 rounded-full bg-white/10 blur-3xl" />
          <div className="mx-auto w-full max-w-[1200px] px-4 md:px-8">
            <motion.div className="mb-8 flex flex-wrap items-end justify-between gap-4" {...fromTop}>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-accent-gold">Platform Highlights</p>
                <h2 className="mt-2 text-3xl font-semibold leading-tight md:text-4xl">Pre-launch essentials in one clean system.</h2>
              </div>
            </motion.div>
            <div className="grid gap-4 md:grid-cols-3">
              {moduleHighlights.map((item, idx) => (
                <motion.div key={item.title} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: idx * 0.06 }} whileHover={card3dHover} style={{ transformStyle: "preserve-3d" }}>
                  <Card className="h-full border border-accent-gold/35 !bg-gradient-to-br from-[#171b18]/85 to-black/20 text-white shadow-lg shadow-black/25">
                    <p className="text-xs font-semibold uppercase tracking-wider text-accent-gold">Module</p>
                    <h3 className="mt-2 text-xl font-semibold">{item.title}</h3>
                    <p className="mt-2 text-sm text-white/80">{item.text}</p>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>
      </main>

      <footer className="relative z-20 border-t border-accent-gold/20 bg-black/80 py-20 text-white backdrop-blur-3xl bollywood-shimmer">
        <div className="mx-auto grid w-full max-w-[1200px] gap-16 px-4 md:grid-cols-4 md:px-8">
          <div className="space-y-6 md:col-span-2">
            <img src={brandLogo} alt="Trade Balance full logo" className="h-16 w-auto object-contain brightness-110" />
            <p className="max-w-md text-base leading-relaxed text-white/70 text-hover-gold">
              Trade Balance delivers a luxury-grade digital journey with cinematic aesthetics and high-conversion storytelling. Experience the next generation of financial networking.
            </p>
            <div className="flex gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-10 w-10 rounded-full border border-accent-gold/30 bg-white/5 transition-all hover:scale-110 hover:border-accent-gold hover:bg-accent-gold/10 pointer-events-auto cursor-pointer flex items-center justify-center">
                  <div className="h-4 w-4 rounded-full bg-accent-gold/40 animate-pulse" />
                </div>
              ))}
            </div>
          </div>
          <div>
            <p className="text-sm font-bold uppercase tracking-widest text-accent-gold mb-6">Explore</p>
            <div className="flex flex-col gap-4 text-sm text-white/60">
              {["Home", "Community", "Launch Video", "Features"].map((l) => (
                <button key={l} type="button" className="text-left transition text-hover-gold hover:text-white" onClick={() => scrollToSection(l.toLowerCase().split(' ')[0])}>{l}</button>
              ))}
            </div>
          </div>
          <div>
            <p className="text-sm font-bold uppercase tracking-widest text-accent-gold mb-6">Legal</p>
            <div className="flex flex-col gap-4 text-sm text-white/60">
              <Link to="/privacy" className="transition text-hover-gold hover:text-white">Privacy Policy</Link>
              <Link to="/terms" className="transition text-hover-gold hover:text-white">Terms & Conditions</Link>
            </div>
          </div>
        </div>
        <div className="mx-auto max-w-[1200px] px-4 md:px-8 mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-white/40">
           <p>© 2026 Trade Balance. All rights reserved.</p>
           <div className="flex gap-6">
             <span className="text-hover-gold cursor-default">Built for Excellence</span>
             <span className="text-hover-gold cursor-default">Privacy Protocol V4.2</span>
           </div>
        </div>
      </footer>
    </div>
  );
}
