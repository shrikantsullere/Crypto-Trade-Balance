import { useMemo, useState } from "react";
import Card from "../components/ui/Card";
import Input from "../components/ui/Input";
import Button from "../components/ui/Button";

export default function NetworkPage() {
  const allRows = [
    { name: "Alex", level: "1", date: "06 Apr 2026", status: "Active" },
    { name: "Nina", level: "2", date: "05 Apr 2026", status: "Active" },
    { name: "Milan", level: "3", date: "04 Apr 2026", status: "Pending" },
  ];
  const [query, setQuery] = useState("");
  const [level, setLevel] = useState("");
  const [appliedQuery, setAppliedQuery] = useState("");
  const [appliedLevel, setAppliedLevel] = useState("");

  const filteredRows = useMemo(() => {
    return allRows.filter((row) => {
      const matchesName = appliedQuery
        ? row.name.toLowerCase().includes(appliedQuery.toLowerCase())
        : true;
      const matchesLevel = appliedLevel ? row.level === appliedLevel : true;
      return matchesName && matchesLevel;
    });
  }, [allRows, appliedQuery, appliedLevel]);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">My Network</h1>
      <Card>
        <div className="grid gap-3 md:grid-cols-3">
          <Input
            label="Search by name or ID"
            placeholder="TB-User"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <Input
            label="Filter by level"
            placeholder="Level 1 - 10"
            value={level}
            onChange={(e) => setLevel(e.target.value.replace(/\D/g, ""))}
          />
          <Button
            className="self-end md:w-fit"
            onClick={() => {
              setAppliedQuery(query.trim());
              setAppliedLevel(level.trim());
            }}
          >
            Apply
          </Button>
        </div>
      </Card>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="Tree View">
          <div className="space-y-3">
            {["You", "Level 1 (4 members)", "Level 2 (12 members)", "Level 3 (26 members)"].map(
              (row, idx) => (
                <div
                  key={row}
                  className="rounded-xl border border-border-subtle bg-page-bg p-3 text-sm"
                  style={{ marginLeft: `${idx * 16}px` }}
                >
                  {row}
                </div>
              )
            )}
          </div>
        </Card>
        <Card title="List View">
          <div className="hidden overflow-x-auto md:block">
            <table className="min-w-full text-left text-sm">
              <thead>
                <tr className="border-b border-border-subtle text-xs uppercase tracking-wide text-text-muted">
                  <th className="px-3 py-2">Member</th>
                  <th className="px-3 py-2">Level</th>
                  <th className="px-3 py-2">Join Date</th>
                  <th className="px-3 py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredRows.map((row) => (
                  <tr key={row.name} className="border-b border-border-subtle/70">
                    <td className="px-3 py-3">{row.name}</td>
                    <td className="px-3 py-3">Level {row.level}</td>
                    <td className="px-3 py-3">{row.date}</td>
                    <td className="px-3 py-3">{row.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="space-y-3 md:hidden">
            {filteredRows.map((row) => (
              <div key={row.name} className="rounded-xl border border-border-subtle p-3 text-sm">
                <p className="font-medium">{row.name}</p>
                <p className="text-text-secondary">Level {row.level}</p>
                <p className="text-text-secondary">{row.date}</p>
                <p className="text-text-secondary">{row.status}</p>
              </div>
            ))}
            {!filteredRows.length ? (
              <div className="rounded-xl border border-border-subtle p-3 text-sm text-text-secondary">
                No members found for selected filters.
              </div>
            ) : null}
          </div>
        </Card>
      </div>
    </div>
  );
}
