import { motion } from "framer-motion";

export default function Input({ label, error, className = "", ...props }) {
  return (
    <motion.label whileFocus={{ scale: 1.005 }} className="block space-y-2">
      {label && (
        <span className="text-sm font-medium text-text-secondary">{label}</span>
      )}
      <input
        className={`h-11 w-full rounded-xl border border-border-subtle bg-white/95 px-3 text-sm text-text-primary outline-none transition-all duration-300 placeholder:text-text-muted focus:border-accent-gold focus:ring-2 focus:ring-accent-gold/20 ${error ? "border-red-500 focus:border-red-500 focus:ring-red-200" : ""} ${className}`}
        {...props}
      />
      {error ? <p className="text-xs text-red-600">{error}</p> : null}
    </motion.label>
  );
}
