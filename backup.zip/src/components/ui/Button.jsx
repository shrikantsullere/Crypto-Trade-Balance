import { motion } from "framer-motion";

export default function Button({
  children,
  className = "",
  variant = "primary",
  type = "button",
  ...props
}) {
  const base =
    "premium-interactive inline-flex h-11 items-center justify-center rounded-xl px-4 text-sm font-semibold transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-gold focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60";
  const variants = {
    primary:
      "bg-gradient-to-r from-brand-green to-[#14533f] text-white shadow-[0_12px_26px_-16px_rgba(15,59,47,0.9)]",
    secondary:
      "border border-brand-green/60 bg-white text-brand-green hover:bg-brand-green-muted",
    ghost: "bg-transparent text-brand-green hover:bg-brand-green-muted",
    danger: "bg-red-600 text-white hover:bg-red-700",
  };
  return (
    <motion.button
      whileHover={{ scale: 1.03, y: -1 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.34, ease: "easeInOut" }}
      type={type}
      className={`${base} ${variants[variant]} ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  );
}
