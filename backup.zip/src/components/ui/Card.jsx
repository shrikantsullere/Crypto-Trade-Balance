import { motion } from "framer-motion";

export default function Card({ title, action, className = "", children }) {
  return (
    <motion.section
      whileHover={{ y: -4 }}
      transition={{ duration: 0.38, ease: "easeInOut" }}
      className={`premium-interactive neo-panel rounded-2xl p-6 transition-all duration-300 ${className}`}
    >
      {(title || action) && (
        <header className="mb-4 flex items-center justify-between gap-4">
          {title ? <h3 className="text-base font-semibold text-brand-green">{title}</h3> : <span />}
          {action}
        </header>
      )}
      {children}
    </motion.section>
  );
}
